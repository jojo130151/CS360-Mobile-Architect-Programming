package com.zybooks.projecttwo;

import android.os.Bundle;
import android.telephony.SmsManager;
import android.telephony.gsm.SmsMessage;
import android.widget.Switch;

import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {
    Switch smsSwitch;
    SmsManager sms;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        sms = getApplicationContext().getSystemService(SmsManager.class);
        //sms.sendTextMessage(?,?,?,?,?);
        smsSwitch = findViewById(R.id.switch1);
        if (smsSwitch.isActivated()) {

        }
        else if (!smsSwitch.isActivated()) {}

    }
}
