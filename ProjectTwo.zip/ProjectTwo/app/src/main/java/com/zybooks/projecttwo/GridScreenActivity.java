package com.zybooks.projecttwo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

import java.util.ArrayList;

public class GridScreenActivity extends AppCompatActivity {

    // Create variables
    InventoryDatabase db;
    android.widget.GridView mainGrid;
    ArrayList<String> inventory;
    ArrayList<Integer> quantities;
    String id;
    GridViewAdapter gridViewAdapter;
    ArrayList<Item> items;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gridscreen);

        Bundle extra = getIntent().getExtras();
        id = extra.getString("id");

        // Populate variables
        db = new InventoryDatabase(this);
        items = new ArrayList<>();

        // Retrieve all titles and quantities of inventory items
        inventory = (db.getInventory(id));
        quantities = (db.getQuantities(id));

        // Iterate through and add items to an ArrayList
        for (int i = 0; i < inventory.size(); i++) {
            try {
                Item item = new Item(inventory.get(i), quantities.get(i));
                items.add(item);
                System.out.println(items.get(i).getTitle() + "  " + items.get(i).getQuantity());
            }
            catch (NullPointerException nullptr) {
                // All for test purposes
                System.out.println("OUTPUT - " + i + " stopped");
                System.out.println(inventory.size() + " = INVENTORY SIZE");
                System.out.println(quantities.size() + " = QUANTITIES SIZE");
                System.out.println(inventory.get(i));
                System.out.println(quantities.get(i));
            }
        }

        // Create and set adapter to create the grids in GridView
        mainGrid = (GridView) findViewById(R.id.mainGrid);
        gridViewAdapter = new GridViewAdapter(this, R.layout.activity_item, items, id);
        mainGrid.setAdapter(gridViewAdapter);
    }


    public void AddClicked(View view) {
        Intent intentAdd = new Intent(GridScreenActivity.this, AddActivity.class);
        intentAdd.putExtra("id", id);
        startActivity(intentAdd);
    }
    public void SettingsClicked(View view) {
        Intent intentSettings = new Intent(GridScreenActivity.this, SettingsActivity.class);
        startActivity(intentSettings);
    }
}