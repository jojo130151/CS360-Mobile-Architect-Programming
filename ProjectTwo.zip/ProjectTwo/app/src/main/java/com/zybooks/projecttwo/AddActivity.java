package com.zybooks.projecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class AddActivity extends AppCompatActivity {

    String id;
    private EditText addTitle;
    EditText addQuantity;
    InventoryDatabase inventoryDb = new InventoryDatabase(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);
        Bundle extra = getIntent().getExtras();
        // Get user id number
        id = extra.getString("id");

        // Get layout fields
        addTitle = findViewById(R.id.editTextItemName);
        addQuantity = findViewById(R.id.editTextQuantity);
    }

    public void SubmitClicked(View view) {
        String title = addTitle.getText().toString();
        String quantity = addQuantity.getText().toString();
        int quantityInt = Integer.parseInt(quantity);

        Item item = new Item();
        // Check that there is no empty fields
        if (title.equals("") || quantity.equals("")) {
            // Restart activity if blank
            Intent intent = new Intent(AddActivity.this, GridScreenActivity.class);
            intent.putExtra("id", id);
            startActivity(intent);
        }
        else {
            // Set Item object with user's values
            item.setQuantity(quantityInt);
            item.setTitle(title);
            item.setId(id);

            // Add new Item to the inventory database
            inventoryDb.addItem(item);

            // Go back to main screen
            Intent intent = new Intent(AddActivity.this, GridScreenActivity.class);
            intent.putExtra("id", id);
            startActivity(intent);
        }

    }
}
