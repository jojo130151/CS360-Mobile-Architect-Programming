package com.zybooks.projecttwo;
import android.content.Context;
import android.content.Intent;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import java.util.ArrayList;

public class GridViewAdapter extends ArrayAdapter<Item> {
    // Set variables
    Context context;
    ArrayList<Item> items;
    InventoryDatabase db;
    PopupWindow popWindow;
    Item oldItem;
    Item item;
    String id;
    ArrayList<String> inventory;
    ArrayList<Integer> quantities;

    public GridViewAdapter(Context applicationContext, int resourceId, ArrayList<Item> items, String id) {
        super(applicationContext, resourceId, items);
        this.context = applicationContext;
        this.items = items;
        db = new InventoryDatabase(applicationContext);
        this.id = id;
        //System.out.println("GridViewAdapter");  // Test
    }
    @Override
    public int getCount() {
        //System.out.println(items.size() + "   ITEMS SIZE"); // Test
        return items.size();
    }

    public static class ViewHolder {
        TextView textTitle;
        TextView textQuantity;
        androidx.appcompat.widget.AppCompatButton gridEdit;
        androidx.appcompat.widget.AppCompatButton gridDelete;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        // Set View, ViewHolder, and layout for grid
        View v = view;
        ViewHolder vh = new ViewHolder();
        v = LayoutInflater.from(getContext()).inflate(R.layout.activity_item, viewGroup,  false);

        // Set ViewHolder variables and set the tag
        vh.textTitle = v.findViewById(R.id.textViewTitle);
        vh.textQuantity = v.findViewById(R.id.textViewQuantity);
        vh.gridEdit = v.findViewById(R.id.ButtonEdit);
        vh.gridDelete = v.findViewById(R.id.gridButtonEdit);
        v.setTag(vh);

        // System.out.println("FROM ADAPTER - " + items.get(i).getTitle() + "   " + items.get(i).getQuantity()); // Test

        // Fill the grid with the items from the inventory
        vh.textTitle.setText(items.get(i).getTitle());
        vh.textQuantity.setText("Quantity: " + items.get(i).getQuantity());

        // Listeners for the edit and delete buttons, only edit is partially done
        final int iPopup = i;
        vh.gridEdit.setOnClickListener(view_1 -> editPopup(iPopup));
        vh.gridDelete.setOnClickListener(view_1 -> {});

        // Return new view
        return v;
    }

    public void editPopup(final int iPopup) {
        // Create a pop up to facilitate user editing an item
        LayoutInflater inflater = LayoutInflater.from(getContext());
        View layout = inflater.inflate(R.layout.activity_edit_item, null, false);

        // Use the parameters from layout for height and width
        int width = GridLayout.LayoutParams.WRAP_CONTENT;
        int height = GridLayout.LayoutParams.WRAP_CONTENT;

        // Create the Pop Up Window
        popWindow = new PopupWindow(layout, width, height, true);
        popWindow.showAtLocation(layout, Gravity.CENTER, 0, 0);

        // Create instances of the EditTexts from the layout
        final EditText editTitle = layout.findViewById(R.id.editTextTextPersonName2);
        final EditText editQty = layout.findViewById(R.id.editTextNumber);

        // Populate the edit text with the old/current item's information
        editTitle.setText(items.get(iPopup).getTitle());
        editQty.setText(String.valueOf(items.get(iPopup).getQuantity()));
        // Create an Item object to use for the edit function in the Inventory Database
        oldItem = new Item(items.get(iPopup).getTitle(), items.get(iPopup).getQuantity());
        oldItem.setId(id);

        // Submit button
        androidx.appcompat.widget.AppCompatButton submit = layout.findViewById(R.id.EditSubmitButton);

        // Listener for Submit button
        submit.setOnClickListener(view -> {
            // Get the user's new information for the item
            String item_title = editTitle.getText().toString();
            String item_quantity = editQty.getText().toString();

            // Create and set the new item's information to an Item object
            item = items.get(iPopup);
            item.setTitle(item_title);
            item.setQuantity(Integer.parseInt(item_quantity));
            item.setId(id);

            //System.out.println(oldItem.getTitle() + " " + oldItem.getQuantity()); // Test
            //System.out.println(item.getTitle() + " " + item.getQuantity());       // Test

            db.editItem(oldItem, item);

            // Redo the new items list
            inventory = (db.getInventory(id));
            quantities = (db.getQuantities(id));
            for (int i = 0; i < inventory.size(); i++) {
                Item itemAdd = new Item(inventory.get(i), quantities.get(i));
                items.add(itemAdd);
            }
            //notifyDataSetChanged();

            popWindow.dismiss();
        });

    }

}
