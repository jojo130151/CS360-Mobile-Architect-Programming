package com.zybooks.projecttwo;

import java.util.ArrayList;

public class Item {

    String id;
    String title;
    int quantity;

    public Item() {}

    public Item(String title, int quantity) {
        this.title = title;
        this.quantity = quantity;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getId() {
        return this.id;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getQuantity() {
        return this.quantity;
    }
}
