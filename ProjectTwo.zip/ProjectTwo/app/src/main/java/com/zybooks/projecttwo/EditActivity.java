package com.zybooks.projecttwo;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;

import static android.Manifest.permission.READ_PHONE_NUMBERS;
import static android.Manifest.permission.READ_PHONE_STATE;
import static android.Manifest.permission.READ_SMS;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class EditActivity extends AppCompatActivity {

    // NOT CURRENTLY IN USE BY PROGRAM - WAS AN EARLIER VERSION OF APPLICATION

    // Set variables
    Item item;
    Item newItem;
    EditText newTitle;
    EditText newQuantity;
    InventoryDatabase db;
    String phoneNumber;
    Switch smsSwitch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        item = new Item();
        setContentView(R.layout.activity_edit_item);
        Bundle extra = getIntent().getExtras();

        // Set Item object with given variables
        item.setId(extra.getString("id"));
        item.setTitle(extra.getString("title"));
        item.setQuantity(extra.getInt("qty"));

        // Assign layout fields
        newTitle = findViewById(R.id.editTextTextPersonName2);
        newQuantity = findViewById(R.id.editTextNumber);
        smsSwitch = findViewById(R.id.switch1);
    }

    public void SubmitClicked(View view) {
        // Variables
        String userTitle;
        int userQty;

        // If blank else populated
        if (newTitle.getText().toString().equals("")) {
            userTitle = item.getTitle();
        } else {
            userTitle = newTitle.getText().toString();
        }

        // System.out.println("PASSED THE USERTITLE CHECK"); // TEST

        // If blank else populated
        if (newQuantity.getText().toString().equals("")) {
            userQty = item.getQuantity();
        } else {
            userQty = Integer.parseInt((newQuantity.getText().toString()));
        }

        //System.out.println("PASSED THE USERQTY CHECK"); // TEST

        // Create new Item object
        newItem = new Item(userTitle, userQty);

        //System.out.println("CREATED THE NEW ITEM"); // TEST
        //System.out.println(item.getTitle() + item.getQuantity()); // TEST
        //System.out.println(newItem.getTitle() + newItem.getQuantity()); // TEST

        db.editItem(item, newItem);

        Intent intent = new Intent(EditActivity.this, GridScreenActivity.class);
        startActivity(intent);

    }
}
