package com.zybooks.projecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    // Variables
    InventoryDatabase inventoryDb = new InventoryDatabase(this);
    EditText username;
    EditText password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        username = findViewById(R.id.editTextTextUsername);
        password = findViewById(R.id.editTextTextPassword);
    }

    public void SubmitClicked(View view) {
        // Get username and password
        String user = username.getText().toString();
        String pass = password.getText().toString();
        // If username or password fields is blank, show Toast to user
        if (user.equals("") ||  pass.equals("")) {
            Toast toast = Toast.makeText(LoginActivity.this, "Please enter in a username and password!", Toast.LENGTH_SHORT);
            toast.show();
            setContentView(R.layout.activity_login);
        }

        String passCheck = inventoryDb.searchPassword(user);
        // Check that password is correct
        if (passCheck.equals(pass)) {
            // Create and populate User object
            User u = new User();
            u.setPassword(pass);
            u.setUsername(user);
            // Get user Id
            u = inventoryDb.getId(u);
            // Start the main Grid screen
            Intent intent = new Intent(LoginActivity.this, GridScreenActivity.class);
            String id = u.getId();
            intent.putExtra("id", id);
            startActivity(intent);
        }
        else {
            //Password does not pass check
            Toast t = Toast.makeText(LoginActivity.this, "Password is not correct!", Toast.LENGTH_SHORT);
            t.show();
        }
    }

    public void SignUpClicked(View view) {
        User user = new User();
        String userStr = username.getText().toString();
        String pass = password.getText().toString();

        // If username or password field is blank, show Toast to user
        if (userStr.equals("") || pass.equals("")) {
            Toast toast = Toast.makeText(LoginActivity.this, "Please enter in a username and password!", Toast.LENGTH_SHORT);
            toast.show();
            setContentView(R.layout.activity_login);
        }
        else {
            // If username is not currently being used
            if (inventoryDb.searchUsernames(userStr)) {
                // Set variables for a User object and add user to Users table
                user.setUsername(userStr);
                user.setPassword(pass);
                user =  inventoryDb.addUser(user);

                // Move to main Grid Screen
                Intent intent = new Intent(LoginActivity.this, GridScreenActivity.class);
                String id = user.getId();
                intent.putExtra("id", id);
                startActivity(intent);
            }
            else {
                // Show Toast to user about username in user
                Toast t = Toast.makeText(LoginActivity.this, "Username is already taken!", Toast.LENGTH_SHORT);
                t.show();
            }

        }
    }
}
