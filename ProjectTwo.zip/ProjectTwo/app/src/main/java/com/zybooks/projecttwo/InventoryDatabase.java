package com.zybooks.projecttwo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class InventoryDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "inventory.db";
    private static final int VERSION = 1;
    SQLiteDatabase db;

    public InventoryDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    // Tables for items in inventory for each user
    private static final class ItemsTable {
        private static final String TABLE = "inventory";
        private static final String COL_TITLE = "title";
        private static final String COL_QUANTITY = "quantity";
    }

    // One table for users signed up
    private static final class UserTable {
        private static final String TABLE = "users";
        private static final String COL_ID = "_id";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create users table
        db.execSQL("create table " + UserTable.TABLE + " (" +
                UserTable.COL_ID + " integer primary key, " +
                UserTable.COL_USERNAME + " text not null unique, " +
                UserTable.COL_PASSWORD + " text not null)");
        this.db = db;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + ItemsTable.TABLE);
        db.execSQL("drop table if exists " + UserTable.TABLE);
        onCreate(db);
    }

    // This function is used for login process
    public String searchPassword(String user) {
        db = this.getReadableDatabase();
        // Look through all entries
        String query = "SELECT username, password FROM users";
        Cursor cursor = db.rawQuery(query, null);
        // Variables to hold each username and password of the table
        String u;
        String p = "Not found";

        // As long as Cursor iterates to next item, search for a matching username and get password
        if (cursor.moveToFirst()) {
            do{
                u = cursor.getString(0);
                if (u.equals(user)) {
                    p = cursor.getString(1);
                    break;
                }
            } while(cursor.moveToNext());
        }
        // Close database and cursor
        cursor.close();
        db.close();
        return p;
    }

    // Add a new user into the Users table
    public User addUser(User user) {
        this.db = this.getWritableDatabase();
        // ContentValues for adding information to table
        ContentValues values = new ContentValues();
        ContentValues valuesItems = new ContentValues();

        // Get the total amount of current users and make this the way we differentiate inventory tables
        Cursor cursor = this.db.rawQuery("SELECT _id FROM users", null);
        int count = cursor.getCount();
        String countStr = String.valueOf(count);
        String table = ItemsTable.TABLE + countStr;

        // Create the user's individual inventory items table
        this.db.execSQL("create table " + table + " (" +
                ItemsTable.COL_TITLE + " text primary key unique, " +
                ItemsTable.COL_QUANTITY + " integer default 0)");

        // Get the users username, password, and count/id and insert
        values.put(UserTable.COL_ID, count);
        values.put(UserTable.COL_USERNAME, user.getUsername());
        values.put(UserTable.COL_PASSWORD, user.getPassword());
        this.db.insert(UserTable.TABLE, null, values);

        // Example item for there to be an already populated list for user to see
        valuesItems.put(ItemsTable.COL_TITLE, "Example");
        valuesItems.put(ItemsTable.COL_QUANTITY, 0);
        this.db.insert(table, null, valuesItems);

        // Set id/count for User item to return with it
        user.setId(countStr);

        // Close database and cursor
        cursor.close();
        db.close();
        return user;
    }

    public ArrayList<String> getInventory(String id) {
        this.db = this.getWritableDatabase();
        ArrayList<String> inventoryItems = new ArrayList<>();
        // Iterate through inventory table and get all item titles
        String query = "SELECT " + ItemsTable.COL_TITLE + " FROM " + ItemsTable.TABLE + id + " ORDER BY " + ItemsTable.COL_TITLE + " ASC";
        Cursor cursorInventory = db.rawQuery(query, null);
        // As long as Cursor continues, add each item title to ArrayList
        if (cursorInventory.moveToFirst()) {
            do{
                inventoryItems.add(cursorInventory.getString(0));
            } while(cursorInventory.moveToNext());
        }

        // Close database and cursor
        cursorInventory.close();
        db.close();
        return inventoryItems;
    }

    public ArrayList<Integer> getQuantities(String id) {
        db = this.getWritableDatabase();
        ArrayList<Integer> quantityItems = new ArrayList<>();
        // Iterate through inventory table and get all item quantities
        String query = "SELECT " + ItemsTable.COL_QUANTITY + " FROM " + ItemsTable.TABLE + id + " ORDER BY " + ItemsTable.COL_TITLE + " ASC";
        Cursor cursorQuantities = db.rawQuery(query, null);
        // As long as Cursor continues, add each item quantity to ArrayList
        if (cursorQuantities.moveToFirst()) {
            do {
                quantityItems.add(cursorQuantities.getInt(0));
            } while (cursorQuantities.moveToNext());
        }
        // Close database and Cursor
        cursorQuantities.close();
        db.close();
        return quantityItems;
    }

    public void addItem(Item item) {
        db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        // Assign values and add to inventory database
        values.put(ItemsTable.COL_TITLE, item.getTitle());
        values.put(ItemsTable.COL_QUANTITY, item.getQuantity());
        db.insert(ItemsTable.TABLE + item.getId(), null, values);
        // Close database
        db.close();
    }

    public User getId(User user) {
        db = this.getReadableDatabase();
        // Retrieve information from user table
        String query = "SELECT _id, username, password FROM users";
        Cursor cursor = db.rawQuery(query, null);
        // Assign variables
        int id = -1;
        String u;
        String p;

        // As long as Cursor iterates, search through to find matching username and password to get the correct id
        if (cursor.moveToFirst()) {
            do{
                u = cursor.getString(1);
                if (u.equals(user.getUsername())) {
                    p = cursor.getString(2);
                    if (p.equals(user.getPassword())) {
                        id = cursor.getInt(0);
                        break;
                    }
                }
            } while(cursor.moveToNext());
        }
        // Assign the id to User object and return
        String idStr = String.valueOf(id);
        user.setId(idStr);

        // Close database and Cursor
        cursor.close();
        db.close();
        return user;
    }

    public boolean searchUsernames(String user) {
        db = this.getReadableDatabase();
        // Iterate through all usernames in users table
        String query = "SELECT username FROM users";
        Cursor cursor = db.rawQuery(query, null);
        String u;
        boolean check = true;

        // As long as Cursor iterates, search to check if username is already in use
        if (cursor.moveToFirst()) {
            do{
                u = cursor.getString(0);
                if (u.equals(user)) {
                    check = false;
                    break;
                }
            } while(cursor.moveToNext());
        }
        // Close database and cursor
        cursor.close();
        db.close();
        return check;
    }

    public Item editItem(Item item, Item newItem) {
        db = this.getWritableDatabase();
        ContentValues newValues = new ContentValues();

        // Get new values and put into ContentValues object
        newValues.put(ItemsTable.COL_TITLE, newItem.getTitle());
        newValues.put(ItemsTable.COL_QUANTITY, newItem.getQuantity());

        // Update the entry in the inventory table
        db.update(ItemsTable.TABLE + item.getId(), newValues, ItemsTable.COL_TITLE + " = " + item.getTitle(), null);
        db.close();
        return item;
    }
}
